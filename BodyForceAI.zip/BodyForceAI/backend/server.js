const express = require("express");
const cors = require("cors");

const app = express();

const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());


// Home / Test route
app.get("/", (req, res) => {
    res.send("Body Force AI Backend is Running! 💪");
});


// Body Analysis API
app.post("/api/analyze", (req, res) => {

    const {
        age,
        gender,
        height,
        weight,
        goal,
        activity
    } = req.body;


    // Check required data
    if (
        !age ||
        !gender ||
        !height ||
        !weight ||
        !goal ||
        !activity
    ) {
        return res.status(400).json({
            success: false,
            message: "Please provide all fitness details."
        });
    }


    // Calculate BMI
    const heightInMeter = height / 100;

    const bmi =
        weight / (heightInMeter * heightInMeter);

    const roundedBMI = bmi.toFixed(1);


    // BMI Category
    let bmiCategory;

    if (bmi < 18.5) {

        bmiCategory = "Underweight";

    } else if (bmi < 25) {

        bmiCategory = "Normal";

    } else if (bmi < 30) {

        bmiCategory = "Overweight";

    } else {

        bmiCategory = "Obesity";
    }


    // Send response
    res.json({

        success: true,

        message: "Body analysis completed successfully!",

        data: {
            age,
            gender,
            height,
            weight,
            goal,
            activity,
            bmi: roundedBMI,
            bmiCategory
        }

    });

});


// Start server
app.listen(PORT, () => {

    console.log(
        `Server running on http://localhost:${PORT}`
    );

});